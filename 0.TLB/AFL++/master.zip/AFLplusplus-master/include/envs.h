
extern char *afl_environment_variables[];

